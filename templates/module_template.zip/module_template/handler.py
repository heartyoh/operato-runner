def handler(input):
    return {'result': 'Hello, Operato!'}
